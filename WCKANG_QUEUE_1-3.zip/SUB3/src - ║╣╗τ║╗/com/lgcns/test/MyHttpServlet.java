package com.lgcns.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.ToNumberPolicy;

class QueueInfoVO {
	int QueueSize;
//	int ProcessTimeout;
//	int MaxFailCount;
//	int WaitTime;
}

class QueueValue {
	String status;
	String messageId;
	String messageString;
}

public class MyHttpServlet extends HttpServlet {

	static HashMap<String, Integer> queueLength = new HashMap<>();
	static HashMap<String, LinkedList<QueueValue>> myQueue = new HashMap<>();

	public String processCommand(String command, String qName, String msg) {

		if (command.equals("CREATE")) {
			// parse json and store to class from body using VO
			Gson gson = new Gson();
			QueueInfoVO queueInfo = gson.fromJson(msg, QueueInfoVO.class);
			System.out.println("QueueSize w/VO = " + queueInfo.QueueSize);

			if (queueLength.containsKey(qName)) {
				return "{\"Result\": \"Queue Exist\"}";
			}
			queueLength.put(qName, Integer.valueOf(queueInfo.QueueSize));
			return "{\"Result\": \"Ok\"}";
		}
		if (command.equals("ACK")) {
			int size = queueLength.getOrDefault(qName, -1);
			if (size == -1) {
				System.out.println("Queue is empty");
				return "{\"Result\": \"No Message\"}";
			}
			if ( myQueue.containsKey(qName) ) {
				LinkedList<QueueValue> q = myQueue.get(qName);
				if (q.size() == 0)
					return "{\"Result\": \"No Message\"}";
				int i=0;
				QueueValue node;
				while (true)
				{
					node = q.get(i);
					if (node.status.equals("SEND"))
						break;
					i++;
				}
				node.status = "RECEIVE";
				q.set(i, node);
				return "{\"Result\": \"OK\", \"MessageID\": \"" + node.messageId + "\"}";
			}
			else
			{
				return "{\"Result\": \"No Message\"}";
			}
		}
		if (command.equals("RECEIVE")) {
			int size = queueLength.getOrDefault(qName, -1);
			if (size == -1) {
				System.out.println("Queue is empty");
				return "{\"Result\": \"No Message\"}";
			}
			if ( myQueue.containsKey(qName) ) {
				LinkedList<QueueValue> q = myQueue.get(qName);
				if (q.size() == 0)
					return "{\"Result\": \"No Message\"}";
				int i=0;
				QueueValue node;
				while (true)
				{
					node = q.get(i);
					if (node.status.equals("SEND"))
						break;
					i++;
				}
				node.status = "RECEIVE";
				q.set(i, node);
				return "{\"Result\": \"OK\", \"MessageID\": \"" + node.messageId + "\"}";
			}
			else
			{
				return "{\"Result\": \"No Message\"}";
			}
		}
		if (command.equals("SEND")) {
			int size = queueLength.getOrDefault(qName, -1);
			if (size == -1) {
				System.out.println("Queue is empty");
				return "ERROR";
			}
			if (myQueue.containsKey(qName)) {
				LinkedList<QueueValue> q = myQueue.get(qName);
				if (q.size() == size) {
					return "{\"Result\": \"Queue Full\"}";
				}
				Gson gson = new Gson();
				@SuppressWarnings("unchecked")
				Map<String, String> map = gson.fromJson(msg, Map.class);
				// System.out.println(map.get("Message").toString() );
				QueueValue n = new QueueValue();
				n.messageId = String.valueOf( new Random().nextInt() );
				n.messageString = map.get("Message");
				n.status = "SEND";
				q.add(n);
			} else {
				LinkedList<QueueValue> q = new LinkedList<>();
				Gson gson = new Gson();
				@SuppressWarnings("unchecked")
				Map<String, String> map = gson.fromJson(msg, Map.class);

				QueueValue n = new QueueValue();
				n.messageId = String.valueOf( new Random().nextInt() );
				n.messageString = map.get("Message");
				n.status = "SEND";

				q.add(n);
				myQueue.put(qName, q);
			}
		}
		return null;

	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//		GET http://127.0.0.1:8080/RECEIVE/<QName>?q1=123&q2=456

		StringBuffer fullURL = req.getRequestURL(); // http://127.0.0.1:8080/RECEIVE/<Queue Name>
		String uriString = req.getRequestURI(); // /RECEIVE/<QName>

		String[] uri = uriString.split("/");
		String command = uri[1]; // RECEIVE
		String qName = uri[uri.length - 1]; // <QName>

		System.out.println("fullURL = " + fullURL);
		System.out.println("uriString = " + uriString);
		System.out.println("command = " + command + ", qName = " + qName);
		System.out.println("Query String : " + req.getQueryString()); // q1=123&q2=456
		System.out.println("Query String : " + req.getParameter("q1")); // 123
		System.out.println("Query String : " + req.getParameter("q2")); // 456

		processCommand(command, qName, "");
		// response message
		PrintWriter out = resp.getWriter();
		out.print("Return...");
		out.flush();
		out.close();

	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

//		POST http://127.0.0.1:8080/CREATE/<QName>

		StringBuffer fullURL = req.getRequestURL(); // http://127.0.0.1:8080/RECEIVE/<Queue Name>
		String uriString = req.getRequestURI(); // /RECEIVE/<QName>

		String[] uri = uriString.split("/");
		String command = uri[1]; // CREATE, RECEIVE
		String qName = uri[uri.length - 1]; // <QName>

		System.out.println("fullURL = " + fullURL);
		System.out.println("uriString = " + uriString);
		System.out.println("command = " + command + ", qName = " + qName);
		System.out.println("Query String : " + req.getQueryString()); // q1=123&q2=456
		System.out.println("Query String : " + req.getParameter("Param1")); // 123

		// copy body
		StringBuffer jb = new StringBuffer();
		String line = null;

		try {
			BufferedReader reader = req.getReader();
			while ((line = reader.readLine()) != null)
				jb.append(line);
		} catch (Exception e) {
		}

		System.out.println("body = " + jb);

		// simply parse json from body
		Gson gson = new Gson();
//		Gson gson = new GsonBuilder()				
//				  .setObjectToNumberStrategy(ToNumberPolicy.BIG_DECIMAL).create();
//		@SuppressWarnings("unchecked")
//		Map<String, Object> map = gson.fromJson(jb.toString(), Map.class);
//		System.out.println(map.get("QueueSize").toString() );
//
//		int size ;// = (int) Math.round( Double.parseDouble (  map.get("QueueSize").toString() ) );
//		Double d = Double.parseDouble (  map.get("QueueSize").toString() );
//		size = d.intValue();
//		
//		System.out.println("QueueSize = " + size);

		// parse json and store to class from body using VO
		QueueInfoVO queueInfo = gson.fromJson(jb.toString(), QueueInfoVO.class);
		System.out.println("QueueSize w/VO = " + queueInfo.QueueSize);

		String result = processCommand(command, qName, jb.toString());

		// response message
//		resp.setContentType("text/html;charset=utf-8");
		// resp.setStatus(500);
		PrintWriter out = resp.getWriter();
		out.print(result);
		out.flush();
		out.close();
	}
}
