package com.lgcns.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Map;
import java.util.Queue;
import java.util.Random;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.ToNumberPolicy;

class QueueInfoVO {
	int QueueSize;
//	int ProcessTimeout;
//	int MaxFailCount;
//	int WaitTime;
}

class QueueValue {
	String status;
	String messageId;
	String messageString;
}

public class MyHttpServlet extends HttpServlet {

	static HashMap<String, Integer> queueLength = new HashMap<>();
	static HashMap<String, LinkedList<QueueValue>> myQueue = new HashMap<>();

	public String processCommand(String uriString, String msg) {

		String[] uri = uriString.split("/");
		String command = uri[1]; // Command
		String qName = uri[2]; // <QName>

		if (command.equals("CREATE")) {

			if (queueLength.containsKey(qName)) {
				return "{\"Result\": \"Queue Exist\"}";
			}

			// parse json and store to class from body using VO
			Gson gson = new Gson();
			QueueInfoVO queueInfo = gson.fromJson(msg, QueueInfoVO.class);

			queueLength.put(qName, Integer.valueOf(queueInfo.QueueSize));
			return "{\"Result\": \"Ok\"}";
		}
		if (command.equals("ACK")) {
			String msgID = uri[3];
			int size = queueLength.getOrDefault(qName, -1);
			if (size == -1) {
				System.out.println("Queue is empty");
				return "{\"Result\": \"Ok\"}";
			}
			if (myQueue.containsKey(qName)) {
				LinkedList<QueueValue> q = myQueue.get(qName);
				if (q.size() == 0)
					return "{\"Result\": \"Ok\"}";

				ListIterator<QueueValue> it = q.listIterator();
				while (it.hasNext()) {
					QueueValue n = it.next();
					if (n.messageId.equals(msgID)) {
						it.remove();

						return "{\"Result\": \"Ok\"}";
					}
				}
			}
			return "{\"Result\": \"Ok\"}";
		}
		if (command.equals("FAIL")) {
			String msgID = uri[3];
			int size = queueLength.getOrDefault(qName, -1);
			if (size == -1) {
				System.out.println("Queue is empty");
				return "{\"Result\": \"Ok\"}";
			}
			if (myQueue.containsKey(qName)) {
				LinkedList<QueueValue> q = myQueue.get(qName);
				if (q.size() == 0)
					return "{\"Result\": \"Ok\"}";

				ListIterator<QueueValue> it = q.listIterator();
				while (it.hasNext()) {
					QueueValue n = it.next();
					if (n.messageId.equals(msgID)) {
						n.status = "SEND";
						it.set(n);

						return "{\"Result\": \"Ok\"}";
					}
				}

//				int i = 0;
//				QueueValue node;
//				while (i < q.size()) {
//					node = q.get(i);
//					if (node.messageId.equals(msgID))
//					{
//						node.status = "SEND";
//						q.set(i, node);
//						return "{\"Result\": \"Ok\"}";
//					}
//					i++;
//				}
				return "{\"Result\": \"Ok\"}";
			}
		}

		if (command.equals("RECEIVE")) {
			int size = queueLength.getOrDefault(qName, -1);
			if (size == -1) {
				System.out.println("Queue is empty");
				return "{\"Result\": \"No Message\"}";
			}
			if (myQueue.containsKey(qName)) {
				LinkedList<QueueValue> q = myQueue.get(qName);
				if (q.size() == 0)
					return "{\"Result\": \"No Message\"}";
				ListIterator<QueueValue> it = q.listIterator();
				while (it.hasNext()) {
					QueueValue n = it.next();
					if (n.status.equals("SEND")) {
						n.status = "RECEIVE";
						it.set(n);

						return "{\"Result\": \"OK\", \"MessageID\": \"" + n.messageId + "\",\"Message\":\""
								+ n.messageString + "\"}";
					}
				}
				return "{\"Result\": \"No Message\"}";
			}
		}
		if (command.equals("SEND")) {

			int size1 = queueLength.getOrDefault(qName, -1);
			if (size1 == -1) {
				System.out.println("Queue is empty");
				return "ERROR"; // abnormal
			}

			Gson gson = new Gson();
			@SuppressWarnings("unchecked")
			Map<String, String> map = gson.fromJson(msg, Map.class);

			LinkedList<QueueValue> q;
			if (myQueue.containsKey(qName)) {
				q = myQueue.get(qName);
				if (q.size() == size1) {
					return "{\"Result\": \"Queue Full\"}";
				}
			} else {
				
				q = new LinkedList<>();
			}
			// System.out.println(map.get("Message").toString() );
			QueueValue n = new QueueValue();
			n.messageId = String.valueOf(new Random().nextInt(0, 10000));
			n.messageString = map.get("Message");
			n.status = "SEND";
			q.add(n);

			myQueue.put(qName, q);
			return "{\"Result\": \"OK\"}";
		}
		return "";
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//		GET http://127.0.0.1:8080/RECEIVE/<QName>?q1=123&q2=456

		String uriString = req.getRequestURI(); // /RECEIVE/<QName>

		String result = processCommand(uriString, "");

		// response message
		PrintWriter out = resp.getWriter();
		out.print(result);
		out.flush();
		out.close();

	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

//		POST http://127.0.0.1:8080/CREATE/<QName>

		String uriString = req.getRequestURI(); // /RECEIVE/<QName>

		// copy body
		StringBuffer jb = new StringBuffer();
		String line = null;

		try {
			BufferedReader reader = req.getReader();
			while ((line = reader.readLine()) != null)
				jb.append(line);
		} catch (Exception e) {
		}

		String result = processCommand(uriString, jb.toString());

		PrintWriter out = resp.getWriter();
		out.print(result);
		out.flush();
		out.close();
	}
}
