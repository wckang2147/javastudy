package com.lgcns.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;

public class RunManager {
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		HashMap<String, Integer> queueLength = new HashMap<>();
		HashMap<String, LinkedList<String>> myQueue = new HashMap<>();
		
		int length;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String line = null;
		while ((line = br.readLine()) != null) {
			if (line.isEmpty())
				continue;
			if ("exit".equals(line)) {
				break;
			}
			//System.out.println("Input value : " + line);
			String[] commandStrings = line.split(" ");
			
			String command = commandStrings[0];
			String qName = commandStrings[1];
			String qValue = commandStrings[2];
			
			switch (command) {
			case "CREATE":
				length = queueLength.getOrDefault(qName, -1);
				if (length == -1) {
					queueLength.put(qName, Integer.valueOf(qValue));
				} else {
					System.out.println("Queue Exist");
				}
				break;
			case "SEND":
				length = queueLength.getOrDefault(qName, -1);
				if (length == -1) {
					// no queue
					//System.err.println("no queue");
					break;
				}
				if (myQueue.containsKey(qName))
				{
					
					LinkedList<String> q = myQueue.get(qName);
					if (q.size() == length)
					{
						//System.err.println("Queue Full");
						break;
					}
					q.add(qValue);
				}				
				else
				{
					LinkedList<String> q = new LinkedList<>();
					q.add(qValue);
					myQueue.put(qName, q);
				}
				break;
			case "RECEIVE":
				
				LinkedList<String> q1 = myQueue.get(qName);
				if ((q1 == null) || q1.size() == 0)
				{
					//System.err.println("empty");
					break;
				}
				String msg;
				msg = q1.getFirst();
				System.out.println(msg);
				q1.removeFirst();
				break;
			}
		}
		br.close();

	}

}
