package com.lgcns.test;


public class QueueInfoVO {
	int QueueSize;
	int ProcessTimeout;
	int MaxFailCount;
	int WaitTime;
	
	@Override
	public String toString() {
		return "QueueInfo [QueueSize = " + QueueSize +  
				", ProcessTimeout = "+ ProcessTimeout + 
				", MaxFailCount = " + MaxFailCount +
				", WaitTime = " + WaitTime;
		
	}
}