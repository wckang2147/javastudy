package com.lgcns.test;

import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.ServerConnector;
import org.eclipse.jetty.servlet.ServletHandler;
import org.eclipse.jetty.util.thread.QueuedThreadPool;

public class RunManager extends Thread {

	static int port = 8080;

	public void start() {
		Server server = new Server();
		ServerConnector http = new ServerConnector(server);
		http.setHost("127.0.0.1");
		http.setPort(port);
		
		server.addConnector(http);

		server.setAttribute(getName(), http);

		ServletHandler servletHandler = new ServletHandler();
		
		servletHandler.addServletWithMapping(MyHttpServlet.class, "/*");
		server.setHandler(servletHandler);

		try {
			server.start();
			System.out.println("Server Start with Port = " + port);
			server.join();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void main(String[] args) {
		
		MyThread th = new MyThread();
		th.start();
		System.out.println("Main");
		// TODO Auto-generated method stub
		RunManager server = new RunManager();
		server.start();

	}


}
