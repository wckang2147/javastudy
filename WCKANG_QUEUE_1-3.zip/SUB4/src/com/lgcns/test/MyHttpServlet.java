package com.lgcns.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Random;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

class QueueValue {
	String status;
	String messageId;
	String messageString;
	LocalTime insertedTime;
	int FailCount;

	@Override
	public String toString() {
		return "QueueValue [status = " + status + ", messageId = " + messageId + ", messageString = " + messageString
				+ ", insertedTime = " + insertedTime + ", FailCount = " + FailCount + "\n";

	}
}

public class MyHttpServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	static HashMap<String, QueueInfoVO> queueInfo = new HashMap<>();
	static HashMap<String, LinkedList<QueueValue>> myQueue = new HashMap<>();

	static HashMap<String, LinkedList<QueueValue>> dlq = new HashMap<>();

	static int g_i = 0;

	public static synchronized String processCommand(String uriString, String msg) {

		try {

			String[] uri = uriString.split("/");
			String command = uri[1]; // Command
			String qName = uri[2]; // <QName>

//			System.out.println("Enter processCommand");
//			System.out.println(uriString);
			if (command.equals("CREATE")) {

				if (queueInfo.containsKey(qName)) {
					return "{\"Result\": \"Queue Exist\"}";
				}

				// parse json and store to class from body using VO
				Gson gson = new Gson();
				QueueInfoVO qInfo = gson.fromJson(msg, QueueInfoVO.class);

				queueInfo.put(qName, qInfo);

//				System.out.println(qInfo);
				return "{\"Result\": \"Ok\"}";
			}
			if (command.equals("ACK")) {
				String msgID = uri[3];
				QueueInfoVO info = queueInfo.getOrDefault(qName, null);
				if (info == null) {
					System.out.println("Queue is empty");
					return "{\"Result\": \"Ok\"}";
				}
				if (myQueue.containsKey(qName)) {
					LinkedList<QueueValue> q = myQueue.get(qName);
					if (q.size() == 0)
						return "{\"Result\": \"Ok\"}";
					int i = 0;
					QueueValue node;
					while (true) {
						node = q.get(i);
						if (node.messageId.equals(msgID))
							break;
						i++;
					}
					q.remove(i);
					// myQueue.put(qName, q);
					return "{\"Result\": \"Ok\"}";
				} else {
					return "{\"Result\": \"Ok\"}";
				}
			}
			if (command.equals("FAIL")) {
				String msgID = uri[3];
				QueueInfoVO info = queueInfo.getOrDefault(qName, null);
				if (info == null) {
					// System.out.println("Queue is empty");
					return "{\"Result\": \"Ok\"}";
				}
				if (myQueue.containsKey(qName)) {
					LinkedList<QueueValue> q = myQueue.get(qName);
					if (q.size() == 0)
						return "{\"Result\": \"Ok\"}";
					int i = 0;
					QueueValue node;
					for (int i1 = 0; i1 < q.size(); i1++) {
						node = q.get(i1);

						if (node.messageId.equals(msgID)) {
							node.status = "SEND";
							node.FailCount++;
							
							
							
							if (node.FailCount > info.MaxFailCount)
							{
								q.remove(i);
								myQueue.put(qName, q);
								
							 	LinkedList<QueueValue> linkedList = MyHttpServlet.dlq.get(qName);
							 	if (linkedList == null)
							 	{
							 		linkedList = new LinkedList<QueueValue>();
							 		linkedList.add(node);
							 	}
							 	else
							 		linkedList.add(node);
							 	
							 	MyHttpServlet.dlq.put(qName, linkedList);
							 	
							 	System.out.println("move by FAIL " + node.messageString);

							}
							else
							{
								q.set(i1, node);
								myQueue.put(qName, q);
							}
							
							

							
							
							return "{\"Result\": \"Ok\"}";
						}
					}
					return "{\"Result\": \"Ok\"}";

				} else {
					return "{\"Result\": \"Ok\"}";
				}
			}
			if (command.equals("DLQ")) {
				
				System.out.println(uriString);
				if (!dlq.containsKey(qName)) {
					return "{\"Result\": \"No Message\"}";
				}
				LinkedList<QueueValue> q = dlq.get(qName);

				//System.out.println("q=" + q);
				if (q.size() == 0) {
					return "{\"Result\": \"No Message\"}";
				}
				QueueValue dlq1 = q.getFirst();
				String msgID = dlq1.messageId;
				String msg1 = dlq1.messageString;
				q.removeFirst();
				return "{\"Result\": \"Ok\", \"MessageID\": \"" + msgID + "\", \"Message\": \"" + msg1 + "\"}";
			}

			if (command.equals("RECEIVE")) {
				LocalDateTime now = null;
				loops: while (true) {
					LocalDateTime receivedTime = LocalDateTime.now();
					QueueInfoVO info = queueInfo.getOrDefault(qName, null);
					if (info == null) {
						System.out.println("Queue is empty");
						return "{\"Result\": \"No Message\"}";
					}
					if (myQueue.containsKey(qName)) {
						LinkedList<QueueValue> q = myQueue.get(qName);
						if (q.size() == 0) {
							System.out.println("q size is zero");
							return "{\"Result\": \"No Message\"}";
						}
						int i = 0;
						QueueValue node;
						while (true) {
							node = q.get(i);
							if (node.status.equals("SEND"))
								break;
							i++;
							if (i == q.size()) {
								now = LocalDateTime.now();
								if (info.WaitTime == 0 || now.isAfter(receivedTime.plusSeconds(info.WaitTime))) {
									return "{\"Result\": \"No Message\"}";
								} else
									continue loops;
							}
						}

						node.status = "RECEIVE";
//					q.set(i, node);

						// myQueue.put(qName, q);
//						System.out.println("node = " + node);
						String ret = "{\"Result\": \"OK\", \"MessageID\": \"" + node.messageId + "\",\"Message\":\""
								+ node.messageString + "\"}";
						System.out.println(node.FailCount + " > " + info.MaxFailCount);
//						System.out.println(ret);
//						System.out.println("inserted time = " + node.insertedTime);
//						System.out.println("now = " + now);
						return ret;
//						return "{\"Result\": \"OK\", \"MessageID\": \"" + node.messageId + "\",\"Message\":\""
//								+ node.messageString + "\"}";

					} else {
						return "{\"Result\": \"No Message\"}";
					}
				}
			}

			if (command.equals("SEND")) {

				QueueInfoVO info = queueInfo.getOrDefault(qName, null);
				if (info == null) {
					System.out.println("Queue is empty");
					return "ERROR"; // abnormal
				}

				Gson gson = new Gson();
				@SuppressWarnings("unchecked")
				Map<String, String> map = gson.fromJson(msg, Map.class);

				LinkedList<QueueValue> q;
				if (myQueue.containsKey(qName)) {
					q = myQueue.get(qName);
					if (q.size() == info.QueueSize) {
						return "{\"Result\": \"Queue Full\"}";
					}
				} else {
					System.out.println("create new q");
					q = new LinkedList<>();
				}
				// System.out.println(map.get("Message").toString() );
				QueueValue n = new QueueValue();

				n.messageId = String.valueOf(g_i++);
//				String.valueOf(new Random().nextInt(0, 10000));
				n.messageString = map.get("Message");
				n.status = "SEND";
				n.FailCount = 0;
				n.insertedTime = LocalTime.now();
				q.add(n);

				myQueue.put(qName, q);
				return "{\"Result\": \"OK\"}";
			}
			return "";
		} finally {
//			System.out.println("Leave processCommand");
		}
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//		GET http://127.0.0.1:8080/RECEIVE/<QName>?q1=123&q2=456

		String uriString = req.getRequestURI(); // /RECEIVE/<QName>
		String[] uri = uriString.split("/");
//		System.out.println(uriString + " GET");
		String result = processCommand(uriString, "");
		// System.out.println("******** Return");
		

		// response message
		PrintWriter out = resp.getWriter();
		out.print(result);
		out.flush();
		out.close();

		try {
			Thread.sleep(10);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

//		POST http://127.0.0.1:8080/CREATE/<QName>
		String uriString = req.getRequestURI(); // /RECEIVE/<QName>

		// copy body
		StringBuffer jb = new StringBuffer();
		String line = null;

		try {
			BufferedReader reader = req.getReader();
			while ((line = reader.readLine()) != null)
				jb.append(line);
		} catch (Exception e) {
		}

//		System.out.println(uriString + " POST");
		String result = processCommand(uriString, jb.toString());

		// System.out.println("******** Return");

		PrintWriter out = resp.getWriter();
		out.print(result);
		out.flush();
		out.close();
		try {
			Thread.sleep(10);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
