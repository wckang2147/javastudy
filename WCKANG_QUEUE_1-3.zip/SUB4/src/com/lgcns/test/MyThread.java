package com.lgcns.test;

import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Queue;

public class MyThread extends Thread {

	private int seq;

	public MyThread(int seq) {
		this.seq = seq;
	}

	public MyThread() {
		this.seq = 0;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub

		

//		static HashMap<String, QueueInfoVO> queueInfo = new HashMap<>();
//		static HashMap<String, LinkedList<QueueValue>> myQueue = new HashMap<>();
		while (true) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			for (Entry<String, LinkedList<QueueValue>> entry : MyHttpServlet.myQueue.entrySet()) {

				String qname = entry.getKey();

				System.out.println(qname);
				QueueInfoVO info = (QueueInfoVO) MyHttpServlet.queueInfo.get(qname);

				if (info.ProcessTimeout == 0)
				{
					System.out.println("timeout is zero" + qname);
					break;
				}

				LinkedList<QueueValue> queue = entry.getValue();

				for (int i = 0; i < queue.size(); i++) {

					QueueValue item = queue.get(i);
					LocalTime now = LocalTime.now();
					if (item.messageString.equals("Message #2"))
					{
						System.out.println(item);
					}
					if (item.status.equals("RECEIVE")) {
						
						if (now.isAfter(item.insertedTime.plusSeconds(info.ProcessTimeout))) {
							System.out.println("restored");
							item.status = "SEND";
							item.FailCount++;
							queue.set(i, item);
							MyHttpServlet.myQueue.put(qname, queue);
						}
					}
					if (item.FailCount > info.MaxFailCount) {
						System.out.println("removed");
						queue.remove(i);
						MyHttpServlet.myQueue.put(qname, queue);
						MyHttpServlet.dlq.add(item);

					}
				}
			}
		}

//		
//		LocalTime time1 = LocalTime.now();
//		try {
//			Thread.sleep(2000);
//		} catch (InterruptedException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
//		
//		LocalTime time2 = LocalTime.now();
//		System.out.println("time1 = " + time1);
//		System.out.println("time2 = " + time2);
//		System.out.println( "diff = " +Math.abs( time2.until(time1, ChronoUnit.SECONDS) ) );
//		try {
//			Thread.sleep(1000);
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
	}

}
