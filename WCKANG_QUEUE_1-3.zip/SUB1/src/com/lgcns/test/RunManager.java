package com.lgcns.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;

public class RunManager {


	public static void main(String[] args)  {

		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			String line = null;
			LinkedList<String> queue = new LinkedList<>();
			
			while ((line = br.readLine()) != null) {
				if (line.isEmpty())
					continue;
				if ("exit".equals(line)) {
					break;
				}
//				System.out.println("Input value : " + line);
//				String[] commandStrings = line.split(" ");
				
				if (line.startsWith("SEND")) {
					if (line.split(" ").length<2)
						continue;
					String value = line.substring("SEND".length()+1);
					
					//System.out.println(value);
					queue.add(value);
					
				}
				else if (line.startsWith("RECEIVE"))
				{
					if (queue.size()>0) {
						System.out.println( queue.getFirst() );
						queue.removeFirst();
					}
					
				}
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		/*
		MyKeyInput keyInput = new MyKeyInput();
		try {
			keyInput.keyIn();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		*/

	}

}
