package com.lgcns.test;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.PrintWriter;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class JettyJsonEchoServer {

    private static final Gson gson = new Gson();
    private static final ExecutorService threadPool = Executors.newFixedThreadPool(10); // 멀티 요청 처리


    public static void main(String[] args) throws Exception {
        // Jetty 서버를 별도 스레드에서 시작
        Thread serverThread = new Thread(() -> {
            try {
                Server server = new Server(8080);

                ServletContextHandler context = new ServletContextHandler(ServletContextHandler.SESSIONS);
                context.setContextPath("/");
                server.setHandler(context);

                context.addServlet(new ServletHolder(new JsonEchoServlet()), "/api/echo");

                server.start();
                System.out.println("✅ 서버가 8080 포트에서 시작되었습니다.");
                server.join(); // 서버 쓰레드 안에서는 대기 (메인 쓰레드 안 막음)
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        serverThread.start(); // 서버 시작

        //  종료 시 처리 로직 등록 (shutdown hook)
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            System.out.println("🛑 서버 종료 중...");
            threadPool.shutdown(); // ExecutorService 정리
        }));
        
        // 여기부터 메인 스레드는 자유롭게 다른 업무 수행 가능
        System.out.println("✅ 메인 스레드는 계속 실행됩니다. 다른 작업 수행 중...");

        // 예시: 추가 업무 수행
        while (true) {
            // 추가 로직: 예를 들어 주기적으로 상태 체크, 데이터 처리 등
            System.out.println("🛠️ 추가 업무 실행 중...");
            Thread.sleep(5000); // 5초마다 작업
        }
    }
    

    public static class JsonEchoServlet extends HttpServlet {

        /**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		@Override
        protected void doGet(HttpServletRequest req, HttpServletResponse resp) {
            threadPool.execute(() -> {
                try {
                    Map<String, String[]> parameterMap = req.getParameterMap();
                    Map<String, String> responseMap = new java.util.HashMap<>();

                    for (Map.Entry<String, String[]> entry : parameterMap.entrySet()) {
                        String key = entry.getKey();
                        String[] values = entry.getValue();
                        if (values != null && values.length > 0) {
                            responseMap.put(key, values[0]);
                        }
                    }

                    resp.setContentType("application/json");
                    resp.setStatus(HttpServletResponse.SC_OK);

                    String jsonResponse = gson.toJson(responseMap);
                    System.out.println("GET 응답: " + jsonResponse);

                    try (PrintWriter out = resp.getWriter()) {
                        out.print(jsonResponse);
                    }

                } catch (Exception e) {
                    resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                    e.printStackTrace();
                }
            });
        }
    	@Override
        protected void doPost(HttpServletRequest req, HttpServletResponse resp) {
            threadPool.execute(() -> {
                try {
                    StringBuilder body = new StringBuilder();
                    try (BufferedReader reader = req.getReader()) {
                        String line;
                        while ((line = reader.readLine()) != null) {
                            body.append(line);
                        }
                    }

                    JsonElement json = JsonParser.parseString(body.toString()); // GSON으로 파싱
                    System.out.println(" 받은 JSON: " + gson.toJson(json));

                    resp.setContentType("application/json");
                    resp.setStatus(HttpServletResponse.SC_OK);

                    try (PrintWriter out = resp.getWriter()) {
                        out.print(gson.toJson(json)); // 받은 JSON 그대로 응답
                    }

                } catch (Exception e) {
                    resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                    e.printStackTrace();
                }
            });
        }
    }
}


