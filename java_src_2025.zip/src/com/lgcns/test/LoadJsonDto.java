package com.lgcns.test;
import java.util.List;

public class LoadJsonDto {
    private String name;
    private int age;
    private String email;
    private Address address;
    private List<String> hobbies;
    private int[] scores;

    public static class Address {
        private String city;
        private String zipCode;

        public String getCity() { return city; }
        public void setCity(String city) { this.city = city; }

        public String getZipCode() { return zipCode; }
        public void setZipCode(String zipCode) { this.zipCode = zipCode; }

        @Override
        public String toString() {
            return "Address{city='" + city + "', zipCode='" + zipCode + "'}";
        }
    }

    // Getter/Setter 생략 가능
    // toString() 포함 권장
    @Override
    public String toString() {
        return "LoadJsonDto{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", email='" + email + '\'' +
                ", address=" + address +
                ", hobbies=" + hobbies +
                ", scores=" + java.util.Arrays.toString(scores) +
                '}';
    }
}
