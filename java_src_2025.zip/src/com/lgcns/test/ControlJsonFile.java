package com.lgcns.test;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class ControlJsonFile {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n=== JSON 로드/저장 메뉴 ===");
            System.out.println("1. 단일 객체 로드");
            System.out.println("2. 리스트 로드");
            System.out.println("3. 맵 로드");
            System.out.println("4. 종료");
            System.out.print("선택: ");
            String option = scanner.nextLine();

            switch (option) {
                case "1":
                    handleSingleObject(scanner);
                    break;
                case "2":
                    handleList(scanner);
                    break;
                case "3":
                    handleMap(scanner);
                    break;
                case "4":
                    return;
                default:
                    System.out.println("잘못된 입력입니다.");
            }
        }
    }

    // 단일 객체 로드/저장 처리
    private static void handleSingleObject(Scanner scanner) {
        System.out.print("불러올 파일명: ");
        String inputFile = scanner.nextLine();

        LoadJsonDto dto = JsonUtil.loadJsonFromFile(inputFile, LoadJsonDto.class);
        if (dto != null) {
            System.out.println("로드된 데이터:\n" + dto);

            System.out.print("저장할 파일명: ");
            String outputFile = scanner.nextLine();
            boolean success = JsonUtil.saveJsonToFile(dto, outputFile);
            System.out.println(success ? "저장 성공" : "저장 실패");
        } else {
            System.out.println("파일 로드 실패");
        }
    }

    // 리스트 로드/저장 처리
    private static void handleList(Scanner scanner) {
        System.out.print("불러올 리스트 파일명: ");
        String inputFile = scanner.nextLine();

        List<LoadJsonDto> list = JsonUtil.loadJsonListFromFile(inputFile, LoadJsonDto.class);
        if (list != null) {
            System.out.println("로드된 리스트:");
            for (int i = 0; i < list.size(); i++) {
                System.out.println("[" + i + "] " + list.get(i));
            }

            System.out.print("저장할 파일명: ");
            String outputFile = scanner.nextLine();
            boolean success = JsonUtil.saveJsonToFile(list, outputFile);
            System.out.println(success ? "저장 성공" : "저장 실패");
        } else {
            System.out.println("리스트 로드 실패");
        }
    }

    // 맵 로드/저장 처리
    private static void handleMap(Scanner scanner) {
        System.out.print("불러올 맵 파일명: ");
        String inputFile = scanner.nextLine();

        Map<String, LoadJsonDto> map = JsonUtil.loadJsonMapFromFile(inputFile, String.class, LoadJsonDto.class);
        if (map != null) {
            System.out.println("로드된 맵:");
            for (Map.Entry<String, LoadJsonDto> entry : map.entrySet()) {
                System.out.println(entry.getKey() + " => " + entry.getValue());
            }

            System.out.print("저장할 파일명: ");
            String outputFile = scanner.nextLine();
            boolean success = JsonUtil.saveJsonToFile(map, outputFile);
            System.out.println(success ? "저장 성공" : "저장 실패");
        } else {
            System.out.println("맵 로드 실패");
        }
    }
}
