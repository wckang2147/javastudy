package com.lgcns.test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class RunManager {

	public void readProxy() throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		BufferedReader fileReader1 = new BufferedReader(new FileReader(br.readLine() + ".txt"));
		BufferedReader fileReader2 = new BufferedReader(new FileReader(fileReader1.readLine()));
		System.out.println(fileReader2.readLine());
		br.close();
		fileReader1.close();
		fileReader2.close();
	}

	@SuppressWarnings("resource")
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		String[] str;
		str = WckangFile.readConsole(" ");

		String serviceString;
		serviceString = WckangFile.findService(str[0], str[1]);
//		serviceString = WckangFile.findService(filenameString, pathString);

		BufferedReader fileReader2 = new BufferedReader(new FileReader(serviceString));
		System.out.println(fileReader2.readLine());
		fileReader2.close();
	}

}
