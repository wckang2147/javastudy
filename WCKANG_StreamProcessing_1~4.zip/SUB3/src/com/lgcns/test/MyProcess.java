package com.lgcns.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class MyProcess {
//
//	public static void byRuntime(String[] command) throws IOException, InterruptedException {
//		Runtime runtime = Runtime.getRuntime();
//		Process process = runtime.exec(command);
//
//		int exitCode = process.waitFor();
//
//		System.out.println("==============");
//		System.out.println("Exit code : " + exitCode);
//		System.out.println("==============");
//
//		StringBuffer sb = new StringBuffer();
//		BufferedReader br = new BufferedReader(new InputStreamReader(process.getInputStream(), "euc-kr"));
//		String line = null;
//
//		while ((line = br.readLine()) != null) {
//			sb.append(line).append("\n");
//		}
//
//		System.out.println(sb.toString());
//	}
//	public void runCmdbyProcess() throws IOException, Exception
//	{
//		String[] command = new String[] { "cmd.exe", "/c", "dir" };
//
//		byRuntime(command);
//	}
	/*
	 * String[] cmdStrings = {"SP_TEST.BAT", "A1", "A2"}; 
	 * runCommand(cmdStrings);
	 */	
	public void runCommand(String[] cmd) throws IOException {
		Process process = new ProcessBuilder(cmd).start();
		BufferedReader stdOut = new BufferedReader(new InputStreamReader(process.getInputStream()));
		String str;
		// ǥ����� ���¸� ���
		while ((str = stdOut.readLine()) != null) {
			System.out.println(str);
		}
	}

}
