package com.lgcns.test;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.eclipse.jetty.client.HttpClient;
import org.eclipse.jetty.client.api.ContentResponse;
import org.eclipse.jetty.client.api.Request;

import org.eclipse.jetty.client.util.StringContentProvider;
import org.eclipse.jetty.http.HttpFields;
import org.eclipse.jetty.http.HttpMethod;
import org.eclipse.jetty.util.Fields;
import org.eclipse.jetty.util.Fields.Field;

public class MyHttpClient {

    public String requestGet(String url) throws Exception {
        HttpClient httpClient = new HttpClient();
        httpClient.start();

//        ContentResponse contentRes = httpClient.newRequest("http://google.com").method(HttpMethod.GET).send();

        Request req = httpClient
                .newRequest(url)
                .method(HttpMethod.GET);
//                .header("X-Header1", "value1")
//                .header("X-Header2", "value2")
//                .header("X-Header3", "value3");
//                .timeout(5, TimeUnit.SECONDS);

        ContentResponse res = req.send();

//        System.out.println("Response status : " + res.getStatus());

        HttpFields resHeaders = res.getHeaders();

//        resHeaders.forEach((httpField) -> {
//            System.out.println("[Response Header] key : " + httpField.getName() + ", value : " + httpField.getValue());
//        });

//        System.out.println(resHeaders.get("content-type"));
//        System.out.println(resHeaders.get("cache-control"));
//        System.out.println(resHeaders.get("date"));

//        System.out.println(res.getContentAsString());

        httpClient.stop();
        return res.getContentAsString();
    }

	public ContentResponse sendHttpSimple(String url, HttpMethod method, String bodyStr) throws Exception {

		HttpClient httpClient = new HttpClient();
		httpClient.start();

		Request request = httpClient.newRequest(url).method(method); // .timeout(5, TimeUnit.SECONDS);

		if (method.equals(HttpMethod.POST))
			request.content(new StringContentProvider(bodyStr, "utf-8"));

//		// set header from parameter
//		for (String headerKey : headers.keySet()) {
//			request.header(headerKey, headers.get(headerKey).toString());
//		}
		// printResHeader(request.getHeaders());

		ContentResponse contentRes = request.send();
		httpClient.stop();
		return contentRes;
	}

}
