package com.lgcns.test;

import java.util.List;

public class MyJsonVO {
	public int inputQueueCount;
	public List<String> inputQueueURIs;
	public String outputQueueURI;
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "{ inputQueueCount = " + inputQueueCount 
				+ " , inputQueueURI = " + inputQueueURIs 
				+ " , outputQueueURI = " + outputQueueURI + "}" ;
	}
}
