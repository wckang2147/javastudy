package com.lgcns.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.management.ManagementFactory;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.jetty.http.HttpMethod;

import com.google.gson.Gson;

class OutputJsonVO {
	public transient Timestamp timestamp;
	public List<String> result;

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "{ result = " + result + "}";
	}
}

public class RunManager implements Runnable {

//	// Worker ���� �� ���� Sample 
	static Worker[] workers;
	int threadSeq;
	static Gson gson;
	static MyJsonVO infoQueue;
	static OutputJsonVO outputVo;
	

	public RunManager(int seq) {
		// TODO Auto-generated constructor stub
		this.threadSeq = seq;
	}

	public int getThreadSeq() {
		return this.threadSeq;
	}

	public static void runCommand(String[] cmd) throws IOException {
		Process process = new ProcessBuilder(cmd).start();
		BufferedReader stdOut = new BufferedReader(new InputStreamReader(process.getInputStream()));
		String str;
		// ǥ����� ���¸� ���
		while ((str = stdOut.readLine()) != null) {
			System.out.println(str);
		}
	}

	private static void getQueueInfo() throws Exception {
		// TODO Auto-generated method stub
		MyHttpClient client = new MyHttpClient();
		String response = client.requestGet("http://127.0.0.1:8080/queueInfo");
//		System.out.println(response);

		gson = new Gson();
		infoQueue = gson.fromJson(response, MyJsonVO.class);
		System.out.println(infoQueue.toString());

	}

	class InputMsg {
		public long timestamp;
		public String value;

		@Override
		public String toString() {
			// TODO Auto-generated method stub
			return "{ timestamp = " + timestamp + " , valueString = " + value + "}";
		}
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		getQueueInfo();

		if (workers == null)
			workers = new Worker[infoQueue.inputQueueCount];

		for (int i = 0; i < infoQueue.inputQueueCount; i++)
			workers[i] = new Worker(i);


		ArrayList<Thread> threads = new ArrayList<>();
		try {
			for (int i = 0; i < infoQueue.inputQueueCount; i++) {
				Thread t = new Thread(new RunManager(i));
				t.start();
				threads.add(t);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("th id = " + threadSeq);


		String urlString = infoQueue.inputQueueURIs.get(threadSeq);
		MyHttpClient client = new MyHttpClient();

		while (true) {
			try {
				String response = client.requestGet(urlString);
				System.out.println(response);

				Gson inputGson = new Gson();
				InputMsg msg = inputGson.fromJson(response, InputMsg.class);
				System.out.println("Input msg = " + msg);

//	            System.out.println("timestamp = " + msg.timestamp);

				String resultString = workers[threadSeq].run(msg.timestamp, msg.value);
				if (resultString != null) {
//	            	System.out.println("result = " + resultString);
//		            System.out.println("output q = " + infoQueue.outputQueueURI);

					String bodyString = String.format("{\"result\":\"%s\"}", resultString);
					client.sendHttpSimple(infoQueue.outputQueueURI, HttpMethod.POST, bodyString);
				}

			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println("TH ID = " + threadSeq);
				e.printStackTrace();
				return;
			}
		}
	}

}
