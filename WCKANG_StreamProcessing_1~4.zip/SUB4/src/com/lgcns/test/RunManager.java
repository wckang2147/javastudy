package com.lgcns.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.ProcessBuilder.Redirect;
import java.lang.management.ManagementFactory;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.jetty.http.HttpMethod;

import com.google.gson.Gson;

class OutputJsonVO {
	public transient long time;
	public List<String> result;

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "{ result = " + result + "}";
	}
}

public class RunManager implements Runnable {

//	// Worker ���� �� ���� Sample 
	static Worker[] workers;
	int threadSeq;
	static Gson gson;
	static MyJsonVO infoQueue;
	static int processId;
	static OutputJsonVO outputVo;

	public RunManager(int seq) {
		// TODO Auto-generated constructor stub
		this.threadSeq = seq;
		outputVo = new OutputJsonVO();
	}

	public int getThreadSeq() {

		return this.threadSeq;
	}

	/*
	 * String[] cmdStrings = {"SP_TEST.BAT", "A1", "A2"}; runCommand(cmdStrings);
	 */
	public static void runCommand(String[] cmd) throws IOException {
		ProcessBuilder builder = new ProcessBuilder(cmd);
		builder.redirectOutput(Redirect.INHERIT);
		builder.redirectError(Redirect.INHERIT);
		Process process = builder.start();

//		BufferedReader stdOut = new BufferedReader(new InputStreamReader(process.getInputStream()));
//		String str;
		// ǥ����� ���¸� ���
//		while ((str = stdOut.readLine()) != null) {
//			System.out.println(str);
//		}
	}

	private static void getQueueInfo() throws Exception {
		// TODO Auto-generated method stub
		MyHttpClient client = new MyHttpClient();
		String response = client.requestGet("http://127.0.0.1:8080/queueInfo");
//		System.out.println(response);

		gson = new Gson();
		infoQueue = gson.fromJson(response, MyJsonVO.class);
		System.out.println(infoQueue.toString());

	}

	class InputMsg {
		public long timestamp;
		public String value;

		@Override
		public String toString() {
			// TODO Auto-generated method stub
			return "{ timestamp = " + timestamp + " , valueString = " + value + "}";
		}
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		getQueueInfo();
		if (args.length == 0)
			processId = 0;
		else {
			System.out.println("args = " + args[0]);
			processId = Integer.valueOf(args[0]);
		}

		if (workers == null)
			workers = new Worker[infoQueue.inputQueueCount];

		for (int i = 0; i < infoQueue.inputQueueCount; i++)
			workers[i] = new Worker(i);

		String[] cmdStrings = new String[infoQueue.processCount];
		// {"SP_TEST.BAT", "process no"};

		if (args.length == 0) {
			for (int i = 1; i < infoQueue.processCount; i++) {
				cmdStrings[0] = "SP_TEST.BAT";
				cmdStrings[1] = String.valueOf(i);
				runCommand(cmdStrings);
			}
		}

		Thread a = new Thread(new RunManager(-1));
		a.start();

		ArrayList<Thread> threads = new ArrayList<>();
		try {
			for (int i = 0; i < infoQueue.threadCount; i++) {
				Thread t = new Thread(new RunManager(i));
				t.start();
				threads.add(t);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void processOutput() throws Exception {
		// TODO Auto-generated method stub
		while (true) {
			long time = System.currentTimeMillis() / 1000;
			System.out.println("Check " + outputVo);
			if (outputVo != null && outputVo.result != null) {
				if (outputVo.time != 0
						&& (time - outputVo.time > 2 || outputVo.result.size() >= infoQueue.outputQueueBatchSize)) {

					MyHttpClient client1 = new MyHttpClient();
					Gson outputGson = new Gson();

					String bodyString;
					bodyString = outputGson.toJson(outputVo);
					System.out.println("Send output = " + bodyString);
					outputVo.time = 0;
					outputVo.result.clear();
					// = String.format("{\"result\":\"%s\"}", resultString);
					client1.sendHttpSimple(infoQueue.outputQueueURI, HttpMethod.POST, bodyString);

				}
			}
			Thread.sleep(10);
		}
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("process id = " + processId + " Thread id = " + threadSeq);
		if (threadSeq == -1) { // output thread
			try {
				processOutput();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return;
		}

		int queNumber;
		queNumber = processId * infoQueue.threadCount + threadSeq;
		System.out.println(processId + " " + threadSeq + " " + queNumber);
		if (queNumber >= infoQueue.inputQueueCount) {
			System.out.println("no input queue");
			return;
		}
		String urlString = infoQueue.inputQueueURIs.get(queNumber);
		MyHttpClient client = new MyHttpClient();

		while (true) {
			try {
				System.out.println("url = " + urlString + processId + threadSeq);

				String response = client.requestGet(urlString);
				System.out.println(response);

				Gson inputGson = new Gson();
				InputMsg msg = inputGson.fromJson(response, InputMsg.class);
				System.out.println("Input msg = " + msg);


				String resultString = workers[queNumber].run(msg.timestamp, msg.value);
				if (resultString != null) {
	            	System.out.println("result = " + resultString);
//		            System.out.println("output q = " + infoQueue.outputQueueURI);

					if (outputVo.result == null || outputVo.result.size() == 0) {
						outputVo.time = System.currentTimeMillis() / 1000;
						
					}
					if (outputVo.result == null)
						outputVo.result = new ArrayList<>();
					outputVo.result.add(resultString);
					System.out.println("result = " + outputVo);

					if (outputVo.result.size() == 2) {
						MyHttpClient client1 = new MyHttpClient();
						Gson outputGson = new Gson();
	
						String bodyString;
						bodyString = outputGson.toJson(outputVo);
						outputVo.time = 0;
						outputVo.result.clear();
						// = String.format("{\"result\":\"%s\"}", resultString);
						client1.sendHttpSimple(infoQueue.outputQueueURI, HttpMethod.POST, bodyString);
					
					}					
					
//	            	String bodyString = String.format("{\"result\":\"%s\"}", resultString);
//		            client.sendHttpSimple(infoQueue.outputQueueURI, HttpMethod.POST, bodyString);
				}

			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println("Process ID = " + processId + "TH ID = " + threadSeq);
				e.printStackTrace();
				return;
			}
		}
	}
}
