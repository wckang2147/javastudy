//package com.lgcns.test;
//
//import java.io.BufferedReader;
//import java.io.IOException;
//import java.io.InputStreamReader;
//import java.lang.management.ManagementFactory;
//import java.util.List;
//
//import com.google.gson.Gson;
//
//public class RunManager2 {
//
////	// Worker ���� �� ���� Sample 
//	static Worker[] workers = new Worker[10];
//	
//	public static void runCommand(String[] cmd) throws IOException {
//		Process process = new ProcessBuilder(cmd).start();
//		BufferedReader stdOut = new BufferedReader(new InputStreamReader(process.getInputStream()));
//		String str;
//		// ǥ����� ���¸� ���
//		while ((str = stdOut.readLine()) != null) {
//			System.out.println(str);
//		}
//	}
//	public static void main(String[] args) throws Exception {
//		// TODO Auto-generated method stub
//
//		String response = MyHttpClient.requestGet("http://127.0.0.1:8080/queueInfo");
////		System.out.println(response);
//		
//		Gson gson = new Gson();
//		MyJsonVO infoQueue = gson.fromJson(response, MyJsonVO.class);
////		System.out.println(infoQueue.toString() );
//
//		System.out.println("args.length = " + args.length);
//		long pid = ManagementFactory.getRuntimeMXBean().getPid();
//
//		System.out.println("PID= " + pid);
//		if (args.length == 2)
//		{
//			System.out.println(args[0] + args[1]);
//		}
//		if (args.length == 0) { // root process
//			String[] cmdStrings = {"SP_TEST.BAT", "A1", "A2"};
//			runCommand(cmdStrings);
//		}
//
////		for (int i = 0; i < infoQueue.inputQueueCount; i++)
////			workers[i] = new Worker(i);
//
//	}
//}
