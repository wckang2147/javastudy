package com.lgcns.test;

import java.util.List;

public class MyJsonVO {
	public int processCount;
	public int threadCount;
	public int outputQueueBatchSize;
	public int inputQueueCount;
	public List<String> inputQueueURIs;
	public String outputQueueURI;
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "{ " 
				+ "processCount = " + processCount
				+ " , threadCount = " + threadCount
				+ " , inputQueueCount = " + inputQueueCount 
				+ " , inputQueueURI = " + inputQueueURIs 
				+ " , outputQueueURI = " + outputQueueURI + "}" ;
	}
}
