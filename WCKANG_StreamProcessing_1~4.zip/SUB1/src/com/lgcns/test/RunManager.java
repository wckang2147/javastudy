package com.lgcns.test;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class RunManager {

//	// Worker ���� �� ���� Sample 
	static Worker[] workers = new Worker[5];

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		for (int i = 0; i < 2; i++)
			workers[i] = new Worker(i);


		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		String line = null;

		while ((line = br.readLine()) != null) {
			// System.out.println("Input value : " + line);

			if (line.isEmpty())
				continue;
			String[] commandStrings = line.split(" ");
			int numWorker = Integer.valueOf(commandStrings[0]);
			
			String result = workers[numWorker].run(commandStrings[1]);
			if (result != null)
				System.out.println(result);

			if ("exit".equals(line)) {
				break;
			}
		}

		br.close();

//		// Worker ���� �� ���� Sample - �Ʒ� 2���� ������ ����� �����ϼ���.
//		Worker worker = new Worker(0);
//		worker.run("VIEW_AD1");
	}
}
