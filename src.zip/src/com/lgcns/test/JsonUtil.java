package com.lgcns.test;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Map;

public class JsonUtil {

    // 이 선언이 꼭 있어야 합니다!
    private static final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    // 단일 객체 로드
    public static <T> T loadJsonFromFile(String filePath, Class<T> clazz) {
        try (FileReader reader = new FileReader(filePath)) {
            return gson.fromJson(reader, clazz);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    // 리스트 로드
    public static <T> List<T> loadJsonListFromFile(String filePath, Class<T> elementClass) {
        try (FileReader reader = new FileReader(filePath)) {
            Type type = TypeToken.getParameterized(List.class, elementClass).getType();
            return gson.fromJson(reader, type);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    // 맵 로드
    public static <K, V> Map<K, V> loadJsonMapFromFile(String filePath, Class<K> keyClass, Class<V> valueClass) {
        try (FileReader reader = new FileReader(filePath)) {
            Type type = TypeToken.getParameterized(Map.class, keyClass, valueClass).getType();
            return gson.fromJson(reader, type);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    // 저장 (객체, 리스트, 맵 모두 가능)
    public static <T> boolean saveJsonToFile(T object, String filePath) {
        try (FileWriter writer = new FileWriter(filePath)) {
            gson.toJson(object, writer);
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
}
