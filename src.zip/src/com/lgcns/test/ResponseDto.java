package com.lgcns.test;

/*
{
  "user": {
    "id": 1,
    "name": "tester"
  },
  "config": {
    "debug": true,
    "timeout": 5000
  },
  "tags": ["java", "jetty", "gson"],
  "metadata": {
    "requestId": "abc-123",
    "source": "client"
  }
}

*/

import java.util.List;
import java.util.Map;

public class ResponseDto {
    private RequestDto.User user;
    private RequestDto.Config config;
    private List<String> tags;
    private Map<String, String> metadata;

    public RequestDto.User getUser() {
        return user;
    }

    public RequestDto.Config getConfig() {
        return config;
    }

    public List<String> getTags() {
        return tags;
    }

    public Map<String, String> getMetadata() {
        return metadata;
    }

    @Override
    public String toString() {
        return "ResponseDto{" +
                "user=" + user +
                ", config=" + config +
                ", tags=" + tags +
                ", metadata=" + metadata +
                '}';
    }
}
