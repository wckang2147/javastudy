package com.lgcns.test;

import com.google.gson.Gson;
import org.eclipse.jetty.client.HttpClient;
import org.eclipse.jetty.client.api.ContentResponse;
import org.eclipse.jetty.client.util.StringContentProvider;
import org.eclipse.jetty.http.HttpHeader;
import org.eclipse.jetty.http.HttpMethod;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class SimpleMultiThreadClient {

    private static final Gson gson = new Gson();

    public static void main(String[] args) {
        // 호출할 서버들
        List<String> urls = List.of(
            "http://localhost:8080/api/echo",
            "http://localhost:8081/api/echo",
            "http://localhost:8082/api/echo"
        );

        // 공통 요청 데이터 생성
        RequestDto.User user = new RequestDto.User(1, "tester");
        RequestDto.Config config = new RequestDto.Config(true, 3000);
        List<String> tags = List.of("java", "thread", "simple");
        Map<String, String> metadata = Map.of("requestId", "simple-call", "source", "basic-client");
        RequestDto request = new RequestDto(user, config, tags, metadata);

        Map<String, String> getParams = Map.of(
                "name", "tester",
                "role", "admin"
        );
        List<Thread> threads = new ArrayList<>();

        for (String url : urls) {
          Thread postThread = new Thread(() -> sendPostRequest(url, request));
          Thread getThread = new Thread(() -> sendGetRequest(url, getParams));
          postThread.start();
          getThread.start();
          threads.add(postThread);
          threads.add(getThread);
        }
        // 모든 스레드가 끝날 때까지 대기
        for (Thread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println("모든 요청 완료");
    }

    private static void sendPostRequest(String url, RequestDto requestDto) {
        HttpClient client = new HttpClient();

        try {
            client.start();
            String json = gson.toJson(requestDto);

            ContentResponse response = client.newRequest(url)
                    .method(HttpMethod.POST)
                    .header(HttpHeader.CONTENT_TYPE, "application/json")
                    .header(HttpHeader.ACCEPT, "application/json")
                    .content(new StringContentProvider(json), "application/json")
                    .send();

            String responseJson = response.getContentAsString();
            ResponseDto responseDto = gson.fromJson(responseJson, ResponseDto.class);

            System.out.println(" 응답 도착 from [" + url + "]:\n" + responseDto);
        } catch (Exception e) {
            System.err.println(" 요청 실패 to [" + url + "]: " + e.getMessage());
        } finally {
            try {
                client.stop();
            } catch (Exception e) {
                // 무시
            }
        }
    }
    private static void sendGetRequest(String url, Map<String, String> params) {
        HttpClient client = new HttpClient();

        try {
            client.start();

            // 쿼리 문자열 만들기
            StringBuilder query = new StringBuilder("?");
            for (Map.Entry<String, String> entry : params.entrySet()) {
                if (query.length() > 1) query.append("&");
                query.append(entry.getKey())
                     .append("=")
                     .append(java.net.URLEncoder.encode(entry.getValue(), java.nio.charset.StandardCharsets.UTF_8));
            }

            String fullUrl = url + query;

            ContentResponse response = client.newRequest(fullUrl)
                    .method(HttpMethod.GET)
                    .header(HttpHeader.ACCEPT, "application/json")
                    .send();

            String json = response.getContentAsString();
            System.out.println(" GET 응답 from [" + fullUrl + "]: " + json);

        } catch (Exception e) {
            System.err.println(" GET 요청 실패 to [" + url + "]: " + e.getMessage());
        } finally {
            try {
                client.stop();
            } catch (Exception e) {
                // 무시
            }
        }
    }
    
    
}
