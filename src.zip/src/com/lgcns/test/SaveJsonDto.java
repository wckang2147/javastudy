package com.lgcns.test;

import java.util.List;

public class SaveJsonDto {
    private String name;
    private int age;
    private String email;
    private Address address;
    private List<String> hobbies;
    private int[] scores;

    public static class Address {
        private String city;
        private String zipCode;

        public String getCity() { return city; }
        public void setCity(String city) { this.city = city; }

        public String getZipCode() { return zipCode; }
        public void setZipCode(String zipCode) { this.zipCode = zipCode; }
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public Address getAddress() { return address; }
    public void setAddress(Address address) { this.address = address; }

    public List<String> getHobbies() { return hobbies; }
    public void setHobbies(List<String> hobbies) { this.hobbies = hobbies; }

    public int[] getScores() { return scores; }
    public void setScores(int[] scores) { this.scores = scores; }
}
