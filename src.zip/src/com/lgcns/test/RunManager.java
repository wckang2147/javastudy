package com.lgcns.test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class RunManager {

	public void readProxy() throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		BufferedReader fileReader1 = new BufferedReader(new FileReader(br.readLine() + ".txt"));
		BufferedReader fileReader2 = new BufferedReader(new FileReader(fileReader1.readLine()));
		System.out.println(fileReader2.readLine());
		br.close();
		fileReader1.close();
		fileReader2.close();
	}
    public void getKeyValue(String filePath, String keyDelimiter, String valueDelimiter) {
//        String filePath = "sample.txt";
//        String keyDelimiter = "#";
//        String valueDelimiter = ",";

        // SINGLE 모드 사용
        FlexibleKeyValueStore storeSingle = new FlexibleKeyValueStore(filePath, keyDelimiter, FlexibleKeyValueStore.Mode.SINGLE, valueDelimiter);
        System.out.println("=== SINGLE MODE ===");
        storeSingle.printAll();
        String resultSingle = storeSingle.get("front");
        System.out.println("front = " + resultSingle);

        // LIST 모드 사용
        FlexibleKeyValueStore storeList = new FlexibleKeyValueStore(filePath, keyDelimiter, FlexibleKeyValueStore.Mode.LIST, valueDelimiter);
        System.out.println("\n=== LIST MODE ===");
        storeList.printAll();
        java.util.List<String> resultList = storeList.get("front");
        System.out.println("front = " + resultList);
    }
    
	@SuppressWarnings("resource")
	public static void main(String[] args) throws IOException {
		
		String[] str;
		str = WckangFile.readConsole(" ");

		String serviceString;
		serviceString = WckangFile.findService(str[0], str[1]);
//		serviceString = WckangFile.findService(filenameString, pathString);

		BufferedReader fileReader2 = new BufferedReader(new FileReader(serviceString));
		System.out.println(fileReader2.readLine());
		fileReader2.close();
	}

}
