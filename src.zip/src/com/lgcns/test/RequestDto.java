package com.lgcns.test;

import java.util.List;
import java.util.Map;

public class RequestDto {
    private User user;
    private Config config;
    private List<String> tags;
    private Map<String, String> metadata;

    public RequestDto(User user, Config config, List<String> tags, Map<String, String> metadata) {
        this.user = user;
        this.config = config;
        this.tags = tags;
        this.metadata = metadata;
    }

    public User getUser() {
        return user;
    }

    public Config getConfig() {
        return config;
    }

    public List<String> getTags() {
        return tags;
    }

    public Map<String, String> getMetadata() {
        return metadata;
    }

    public static class User {
        private int id;
        private String name;

        public User(int id, String name) {
            this.id = id;
            this.name = name;
        }

        public int getId() { return id; }
        public String getName() { return name; }

        @Override
        public String toString() {
            return "User{id=" + id + ", name='" + name + "'}";
        }
    }

    public static class Config {
        private boolean debug;
        private int timeout;

        public Config(boolean debug, int timeout) {
            this.debug = debug;
            this.timeout = timeout;
        }

        public boolean isDebug() { return debug; }
        public int getTimeout() { return timeout; }

        @Override
        public String toString() {
            return "Config{debug=" + debug + ", timeout=" + timeout + "}";
        }
    }

    @Override
    public String toString() {
        return "RequestDto{" +
                "user=" + user +
                ", config=" + config +
                ", tags=" + tags +
                ", metadata=" + metadata +
                '}';
    }
}
